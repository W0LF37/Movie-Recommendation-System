# Movie Recommendation System

A university machine learning project exploring collaborative filtering, rating prediction, and personalized movie recommendations using the **MovieLens 20M** dataset.

## Overview

The project analyzes user–movie ratings, engineers features from user–item interactions, compares several recommendation and regression approaches, and generates top-10 movie recommendations for selected users using **SVD++**.

## Methods explored

- Exploratory data analysis and rating-distribution visualization
- Train/test preparation and sparse user–item matrices
- User–user and item–item cosine similarity
- Rating-based feature engineering and XGBoost regression
- Surprise `BaselineOnly`, `KNNBaseline` (user-based and item-based), `SlopeOne`, `SVD`, and `SVDpp`
- Hyperparameter search, RMSE/MAPE evaluation, and model comparisons
- Top-N recommendation generation with movie titles and genres

## Dataset

[MovieLens 20M](https://grouplens.org/datasets/movielens/20m/) by GroupLens. Dataset files are **not included** in this repository.

The notebook initially downloads and extracts `ml-20m.zip` and expects the data under `/content/ml-20m/` (Google Colab convention). Files used include `ratings.csv` and `movies.csv`.

## How to run

1. Open `Movie_Recommendation_System.ipynb` in **Google Colab**.
2. Use a runtime with adequate RAM and disk capacity; full similarity computations and model tuning can be expensive.
3. Run the notebook sequentially. Its first cells download and extract MovieLens 20M and install `fuzzywuzzy` and `scikit-surprise`.
4. If running locally, replace all `/content/ml-20m/` paths with the local dataset directory and install the required Python libraries.

**Compatibility note:** This is an archived university notebook. Some code uses older pandas and XGBoost APIs (such as `DataFrame.append` and XGBoost's `silent` argument). Modern Python/library versions may need compatibility fixes. Successful end-to-end execution on current environments has **not** been verified.

## Repository contents

- `Movie_Recommendation_System.ipynb` — original project notebook, including saved outputs
- `requirements.txt` — primary Python dependencies (unpinned; original versions not recorded)
- `.gitignore` — excludes local dataset, caches, and generated artifacts

## Evaluation notes

The notebook reports RMSE and MAPE for rating prediction. These measures should not be interpreted as ranking-quality metrics (such as Precision@K or NDCG@K). The displayed Top-N recommendations are generated from predicted ratings on an anti-testset, not evaluated by a dedicated ranking benchmark.

## Project status

**University project / archived notebook.** Shared for reproducibility review and portfolio purposes; it has not been refactored as a production-ready application.

## Dataset attribution

Harper, F. M., & Konstan, J. A. (2015). *The MovieLens Datasets: History and Context.* ACM Transactions on Interactive Intelligent Systems, 5(4), Article 19. https://doi.org/10.1145/2827872
